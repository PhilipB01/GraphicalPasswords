package testAndData;

public class Telemetry {
/* Records any relevant statistics and telemetric data to help evaluate 
 *  security/usability, record login attempts/successes and outputs data
 *  to test file "data.txt" for review
 */
}
